import os
from pydantic import BaseSettings

from functools import lru_cache

from azure.identity import DefaultAzureCredential
from azure.keyvault.keys import KeyClient
from azure.keyvault.secrets import *

PROJECT_NAME = "vasudha"

try:
    SQLALCHEMY_DATABASE_URI = os.environ["POSTGRES_URI"]
except:
    SQLALCHEMY_DATABASE_URI = None

API_V1_STR = "/api/v1"

FILE_DIR = "./files"


class Settings(BaseSettings):
    class Config:
        env_file = ".env"

    PROJECT_NAME: str = PROJECT_NAME
    SQLALCHEMY_DATABASE_URI: str = SQLALCHEMY_DATABASE_URI
    API_V1_STR: str = API_V1_STR
    FILE_DIR: str = FILE_DIR
    KEYVAULT_URI: str = "https://optimizationserviceapiva.vault.azure.net/"


@lru_cache
def get_settings():
    return Settings()


class AzureSettings:
    credential: DefaultAzureCredential = DefaultAzureCredential()
    settings: BaseSettings = get_settings()
    SERVICE_BUS_CONNECTION_STR: str = ""
    BLOB_ACCOUNT_URL: str = ""
    MILP_TOPIC: str = "sb-milp-message-topic"
    HEURISTIC_TOPIC: str = "sb-hueristic-topic"
    RL_TOPIC: str = "sb-reinforcementlearning-topic"


@lru_cache
def get_azure_settings():
    return AzureSettings()
