import typing as t


from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from dfdb.models import market as market_
from dfdb.schemas.market import MarketCreate, MarketEdit, MarketDelete, Market


def get_market(db: Session, id: int):
    market = db.query(market_.Market).filter(market_.Market.id == id).first()
    if not market:
        raise HTTPException(status_code=404, detail="Market not found")

    return market


def get_markets(db: Session):
    markets = db.query(market_.Market).all()
    return markets


def create_market(db: Session, market: MarketCreate):
    db_market = market_.Market(**market.dict())
    db.add(db_market)
    db.commit()
    db.refresh(db_market)
    return db_market


def edit_market(db: Session, market: MarketEdit):
    db_market = get_market(db, market.id)

    update_market = market.dict(exclude_unset=True)
    for key, value in update_market.items():
        setattr(db_market, key, value)

    db.commit()
    db.refresh(db_market)
    return db_market


def delete_market(db: Session, market_id: int):
    db_market = get_market(db, market_id)
    db.delete(db_market)
    db.commit()
    return db_market
