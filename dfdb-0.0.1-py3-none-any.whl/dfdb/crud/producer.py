import typing as t

from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from dfdb.models import producer as producer_
from dfdb.schemas.producer import (
    Producer,
    ProducerCreate,
    ProducerEdit,
    ProducerOut,
)
from dfdb.schemas.user import UserOut


def get_producer(db: Session, producer_id: int):
    producer = (
        db.query(producer_.Producer)
        .filter(producer_.Producer.id == producer_id)
        .first()
    )
    if not producer:
        raise HTTPException(status_code=404, detail="Producer not found")
    return producer


def get_producer_of_user(db: Session, user_id: int):
    producer = (
        db.query(producer_.Producer)
        .filter(producer_.Producer.owner_id == user_id)
        .first()
    )
    if not producer:
        raise HTTPException(
            status_code=404, detail="No producers for current user"
        )
    return producer


def get_producers(
    db: Session, skip: int = 0, limit: int = 100
) -> t.List[ProducerOut]:
    return db.query(producer_.Producer).offset(skip).limit(limit).all()


def create_producer(db: Session, producer: ProducerCreate, user: UserOut):
    db_producer = producer_.Producer(
        name=producer.name,
        email=user.email,
        is_active=True,
        description=producer.description,
        net_carbon_emissions=producer.net_carbon_emissions,
        profit=producer.profit,
        owner_id=user.id,
        location=producer.location,
    )
    db.add(db_producer)
    db.commit()
    db.refresh(db_producer)
    return db_producer

def create_producer_without_auth(db: Session, producer: ProducerCreate, user_id: int, email: str):
    db_producer = producer_.Producer(
        name=producer.name,
        email=email,
        is_active=True,
        description=producer.description,
        net_carbon_emissions=producer.net_carbon_emissions,
        profit=producer.profit,
        owner_id=user_id,
        location=producer.location,
    )
    db.add(db_producer)
    db.commit()
    db.refresh(db_producer)
    return db_producer

def edit_producer(db: Session, producer_id: int, producer: ProducerEdit):
    db_producer = get_producer(db, producer_id)
    if not db_producer:
        raise HTTPException(
            status.HTTP_404_NOT_FOUND, detail="Producer not found"
        )

    update_producer = producer.dict(exclude_unset=True)
    for key, value in update_producer.items():
        setattr(db_producer, key, value)

    db.add(db_producer)
    db.commit()
    db.refresh(db_producer)
    return db_producer


def delete_producer(db: Session, producer_id: int):
    producer = get_producer(db, producer_id)
    if not producer:
        raise HTTPException(
            status.HTTP_404_NOT_FOUND, detail="Producer not found"
        )
    db.delete(producer)
    db.commit()
    return producer
