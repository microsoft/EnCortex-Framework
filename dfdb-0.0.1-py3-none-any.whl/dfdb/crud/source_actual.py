from datetime import datetime
import typing as t

from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from dfdb.models import source_actual as source_actual_
from dfdb.schemas.source_actual import (
    SourceActualCreate,
    SourceActualEdit,
    SourceActualOut,
    SourceActual,
)


def get_source_actual_data(db: Session, source_actual_id: int):
    source_actual_data = (
        db.query(source_actual_.SourceActual)
        .filter(source_actual_.SourceActual.id == source_actual_id)
        .first()
    )
    if not source_actual_data:
        raise HTTPException(
            status_code=404, detail="Source Actual data not found"
        )

    return source_actual_data


def get_source_actual_data_by_time(db: Session, source_actual_time: datetime):
    source_actual_data = (
        db.query(source_actual_.SourceActual)
        .filter(source_actual_.SourceActual.data_time == source_actual_time)
        .first()
    )
    if not source_actual_data:
        raise HTTPException(
            status_code=404, detail="Source Actual data not found"
        )

    return source_actual_data


def get_source_actual_data_before_time(
    db: Session, source_actual_time: datetime
):
    source_actual_data = db.query(source_actual_.SourceActual).filter(
        source_actual_.SourceActual.data_time <= source_actual_time
    )
    if not source_actual_data:
        raise HTTPException(
            status_code=404,
            detail="Source Actual data not found before this time",
        )

    return source_actual_data


def get_source_actual_data_after_time(
    db: Session, source_actual_time: datetime
):
    source_actual_data = db.query(source_actual_.SourceActual).filter(
        source_actual_.SourceActual.data_time >= source_actual_time
    )
    if not source_actual_data:
        raise HTTPException(
            status_code=404,
            detail="Source Actual data not found after this time",
        )

    return source_actual_data


def get_source_actual_data_interval_time(
    db: Session,
    source_actual_start_time: datetime,
    source_actual_end_time: datetime,
):
    source_actual_data = (
        db.query(source_actual_.SourceActual)
        .filter(
            source_actual_.SourceActual.data_time >= source_actual_start_time
        )
        .filter(source_actual_.SourceActual.data_time <= source_actual_end_time)
    )
    if not source_actual_data:
        raise HTTPException(
            status_code=404,
            detail="Source Actual data not found in this tnterval",
        )

    return source_actual_data


def create_source_actual_data(
    db: Session, source_actual_data: t.Iterable, source_id: int
):
    source_actual_data = list(
        map(
            lambda data_point: source_actual_.SourceActual(
                data=data_point.data,
                data_time=data_point.time,
                source_id=source_id,
            ),
            source_actual_data,
        )
    )
    db.bulk_save_objects(source_actual_data)
    db.commit()
    return source_actual_data


def delete_source_actual_data(db: Session, source_actual_ids: t.List[int]):
    source_actual_data = db.query(source_actual_.SourceActual).filter(
        source_actual_.SourceActual.id.in_(source_actual_ids)
    )
    if not source_actual_data:
        raise HTTPException(
            status_code=404, detail="Source Actual data not found"
        )

    db.delete(source_actual_data)
    db.commit()
    return source_actual_data
