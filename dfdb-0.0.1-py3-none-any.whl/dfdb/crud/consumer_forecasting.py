import typing as t
from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from dfdb.models import consumer_forecasting as consumer_forecasting_model
from dfdb.schemas.consumer_forecasting import ConsumerForecasting, ConsumerForecastingEdit, ConsumerForecastingCreate, ConsumerForecastingDelete

def create_consumer_forecasting_record(db: Session, consumer_forecasting: ConsumerForecastingCreate):
    db_consumer_forecasting = consumer_forecasting_model.ConsumerForecasting (**consumer_forecasting.dict())
    db.add(db_consumer_forecasting)
    db.commit()
    return db_consumer_forecasting


def get_consumer_forecasting_record(db: Session, entity_forecasting_id: int):
    consumer_forecasting_record = db.query(consumer_forecasting_model.ConsumerForecasting)\
        .filter(consumer_forecasting_model.ConsumerForecasting.entity_forecasting_id == entity_forecasting_id)\
        .first()
    
    if not consumer_forecasting_record:
        raise HTTPException(status_code=404, detail="consumer forecasting record not found")

    return consumer_forecasting_record

def get_consumer_forecasting_records(db: Session):
    consumer_forecasting_records = db.query(consumer_forecasting_model.ConsumerForecasting).all()
    return consumer_forecasting_records