import typing as t


from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from dfdb.models import forecaster as forecaster_model
from dfdb.schemas.forecaster import ForecasterCreate, ForecasterEdit, ForecasterDelete, Forecaster
from dfdb.schemas.producer import (
    Producer,
    ProducerCreate,
    ProducerEdit,
    ProducerOut,
)

def create_forecaster(db: Session, forecaster: ForecasterCreate):
    db_forecaster = forecaster_model.Forecaster(**forecaster.dict())
    db.add(db_forecaster)
    db.commit()
    return db_forecaster


def create_default_forecaster_for_producer(db: Session, producer: ProducerCreate, user_id: int):
    # name = producer name forecaster, description - default forecaster for proudercer x to provide forecast for all its entities , location, owner = proudercer owner 
    return create_forecaster(db, forecaster=  ForecasterCreate(
        name=producer.name + "forecaster",
        description="Default forecaster for producer to provide forecasts for all its entites",
        location = "",
        owner_id=user_id)
        );
    
    

# def get_market(db: Session, id: int):
#     market = db.query(market_.Market).filter(market_.Market.id == id).first()
#     if not market:
#         raise HTTPException(status_code=404, detail="Market not found")

#     return market


# def get_markets(db: Session):
#     markets = db.query(market_.Market).all()
#     return markets


# def edit_market(db: Session, market: MarketEdit):
#     db_market = get_market(db, market.id)

#     update_market = market.dict(exclude_unset=True)
#     for key, value in update_market.items():
#         setattr(db_market, key, value)

#     db.commit()
#     db.refresh(db_market)
#     return db_market


# def delete_market(db: Session, market_id: int):
#     db_market = get_market(db, market_id)
#     db.delete(db_market)
#     db.commit()
#     return db_market
