import typing as t


from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from dfdb.models import source_forecasting as source_forecasting_model
from dfdb.schemas.source_forecasting import SourceForecasting, SourceForecastingEdit, SourceForecastingCreate, SourceForecastingDelete

def create_source_forecasting_record(db: Session, source_forecasting: SourceForecastingCreate):
    db_source_forecasting = source_forecasting_model.SourceForecasting (**source_forecasting.dict())
    db.add(db_source_forecasting)
    db.commit()
    return db_source_forecasting


def get_source_forecasting_record(db: Session, entity_forecasting_id: int):
    source_forecasting_record = db.query(source_forecasting_model.SourceForecasting)\
        .filter(source_forecasting_model.SourceForecasting.entity_forecasting_id == entity_forecasting_id)\
        .first()
    
    if not source_forecasting_record:
        raise HTTPException(status_code=404, detail="source forecasting record not found")

    return source_forecasting_record

def get_source_forecasting_records(db: Session):
    source_forecasting_records = db.query(source_forecasting_model.SourceForecasting).all()
    return source_forecasting_records