from datetime import datetime
import typing as t
from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from dfdb.models import market_forecast_clearing_volume as market_forecast_clearing_volume_model
from dfdb.schemas.market_forecast_clearing_volume import MarketForecastClearingVolume, MarketForecastClearingVolumeCreate

def create_market_forecast_clearing_volume(db: Session, market_forecast_clearing_volume: MarketForecastClearingVolumeCreate):
    db_market_forecast_clearing_volume = market_forecast_clearing_volume_model.MarketForecastClearingVolume (**market_forecast_clearing_volume.dict())
    db.add(db_market_forecast_clearing_volume)
    db.commit()
    return db_market_forecast_clearing_volume


def get_market_forecast_clearing_volume(db: Session, market_id: int, timestamp: datetime, timestep: int):
    
    forecast_data_stored = (
            db.query(
                market_forecast_clearing_volume_model.MarketForecastClearingVolume
            )
            .filter(
                market_forecast_clearing_volume_model.MarketForecastClearingVolume.market_id
                == market_id,
                 market_forecast_clearing_volume_model.MarketForecastClearingVolume.start_timestamp
                == timestamp,
                 market_forecast_clearing_volume_model.MarketForecastClearingVolume.timestep
                == timestep
            )
            .first()
        )
    
    if not forecast_data_stored:
        raise HTTPException(status_code=404, detail="Market forecast not found")

    return forecast_data_stored

def get_market_forecasts_clearing_volume(db: Session):
    market_forecasts_clearing_volume = db.query(market_forecast_clearing_volume_model.MarketForecastClearingVolume).all()
    return market_forecasts_clearing_volume