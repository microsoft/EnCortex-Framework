from datetime import datetime
import typing as t
from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from dfdb.models import source_actual_generation as source_actual_generation_model
from dfdb.schemas.source_actual_generation import SourceActualGeneration, SourceActualGenerationCreate

def create_source_actual_generation(db: Session, source_actual_generation: SourceActualGenerationCreate):
    db_source_actual_generation = source_actual_generation_model.SourceActualGeneration (**source_actual_generation.dict())
    db.add(db_source_actual_generation)
    db.commit()
    return db_source_actual_generation


def get_source_actual_generation(db: Session, source_id: int, timestamp: datetime, timestep: int):
    
    actual_data_stored = (
            db.query(
                source_actual_generation_model.SourceActualGeneration
            )
            .filter(
                source_actual_generation_model.SourceActualGeneration.source_id
                == source_id,
                 source_actual_generation_model.SourceActualGeneration.start_timestamp
                == timestamp,
                 source_actual_generation_model.SourceActualGeneration.timestep
                == timestep
            )
            .first()
        )
    
    if not actual_data_stored:
        raise HTTPException(status_code=404, detail="source actual not found")

    return actual_data_stored

def get_source_actuals_generation(db: Session):
    source_actuals_generation = db.query(source_actual_generation_model.SourceActualGeneration).all()
    return source_actuals_generation