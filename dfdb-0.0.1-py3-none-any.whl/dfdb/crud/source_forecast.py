from datetime import datetime
import typing as t

from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from dfdb.models import source_forecast as source_forecast_
from dfdb.schemas.source_forecast import (
    SourceForecastCreate,
    SourceForecastEdit,
    SourceForecastOut,
    SourceForecast,
)


def get_source_forecast_data(db: Session, source_forecast_id: int):
    source_forecast_data = (
        db.query(source_forecast_.SourceForecast)
        .filter(source_forecast_.SourceForecast.id == source_forecast_id)
        .first()
    )
    if not source_forecast_data:
        raise HTTPException(
            status_code=404, detail="Source Forecast data not found"
        )

    return source_forecast_data


def get_source_forecast_data_by_time(
    db: Session, source_forecast_time: datetime
):
    source_forecast_data = (
        db.query(source_forecast_.SourceForecast)
        .filter(
            source_forecast_.SourceForecast.data_time == source_forecast_time
        )
        .first()
    )
    if not source_forecast_data:
        raise HTTPException(
            status_code=404, detail="Source Forecast data not found"
        )

    return source_forecast_data


def get_source_forecast_data_before_time(
    db: Session, source_forecast_time: datetime
):
    source_forecast_data = db.query(source_forecast_.SourceForecast).filter(
        source_forecast_.SourceForecast.data_time <= source_forecast_time
    )
    if not source_forecast_data:
        raise HTTPException(
            status_code=404,
            detail="Source Forecast data not found before this time",
        )

    return source_forecast_data


def get_source_forecast_data_after_time(
    db: Session, source_forecast_time: datetime
):
    source_forecast_data = db.query(source_forecast_.SourceForecast).filter(
        source_forecast_.SourceForecast.data_time >= source_forecast_time
    )
    if not source_forecast_data:
        raise HTTPException(
            status_code=404,
            detail="Source Forecast data not found after this time",
        )

    return source_forecast_data


def get_source_forecast_data_interval_time(
    db: Session,
    source_forecast_start_time: datetime,
    source_forecast_end_time: datetime,
):
    source_forecast_data = (
        db.query(source_forecast_.SourceForecast)
        .filter(
            source_forecast_.SourceForecast.data_time
            >= source_forecast_start_time
        )
        .filter(
            source_forecast_.SourceForecast.data_time
            <= source_forecast_end_time
        )
    )
    if not source_forecast_data:
        raise HTTPException(
            status_code=404,
            detail="Source Forecast data not found in this tnterval",
        )

    return source_forecast_data


def create_source_forecast_data(
    db: Session, source_forecast_data: t.Iterable, source_id: int
):
    source_forecast_data = list(
        map(
            lambda data_point: source_forecast_.SourceForecast(
                data=data_point.data,
                data_time=data_point.time,
                source_id=source_id,
            ),
            source_forecast_data,
        )
    )
    db.bulk_save_objects(source_forecast_data)
    db.commit()
    return source_forecast_data


def delete_source_forecast_data(db: Session, source_forecast_ids: t.List[int]):
    source_forecast_data = db.query(source_forecast_.SourceForecast).filter(
        source_forecast_.SourceForecast.id.in_(source_forecast_ids)
    )
    if not source_forecast_data:
        raise HTTPException(
            status_code=404, detail="Source Forecast data not found"
        )

    db.delete(source_forecast_data)
    db.commit()
    return source_forecast_data
