import typing as t


from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from dfdb.models import grid_forecasting as grid_forecasting_model
from dfdb.schemas.grid_forecasting import GridForecasting, GridForecastingEdit, GridForecastingCreate, GridForecastingDelete

def create_grid_forecasting_record(db: Session, grid_forecasting: GridForecastingCreate):
    db_grid_forecasting = grid_forecasting_model.GridForecasting (**grid_forecasting.dict())
    db.add(db_grid_forecasting)
    db.commit()
    return db_grid_forecasting


def get_grid_forecasting_record(db: Session, entity_forecasting_id: int):
    grid_forecasting_record = db.query(grid_forecasting_model.GridForecasting)\
        .filter(grid_forecasting_model.GridForecasting.entity_forecasting_id == entity_forecasting_id)\
        .first()
    
    if not grid_forecasting_record:
        raise HTTPException(status_code=404, detail="Grid forecasting record not found")

    return grid_forecasting_record

def get_grid_forecasting_records(db: Session):
    grid_forecasting_records = db.query(grid_forecasting_model.GridForecasting).all()
    return grid_forecasting_records