from datetime import datetime
import typing as t
from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from dfdb.models import market_forecast_clearing_price as market_forecast_clearing_price_model
from dfdb.schemas.market_forecast_clearing_price import MarketForecastClearingPrice, MarketForecastClearingPriceCreate

def create_market_forecast_clearing_price(db: Session, market_forecast_clearing_price: MarketForecastClearingPriceCreate):
    db_market_forecast_clearing_price = market_forecast_clearing_price_model.MarketForecastClearingPrice (**market_forecast_clearing_price.dict())
    db.add(db_market_forecast_clearing_price)
    db.commit()
    return db_market_forecast_clearing_price


def get_market_forecast_clearing_price(db: Session, market_id: int, timestamp: datetime, timestep: int):
    
    forecast_data_stored = (
            db.query(
                market_forecast_clearing_price_model.MarketForecastClearingPrice
            )
            .filter(
                market_forecast_clearing_price_model.MarketForecastClearingPrice.market_id
                == market_id,
                 market_forecast_clearing_price_model.MarketForecastClearingPrice.start_timestamp
                == timestamp,
                 market_forecast_clearing_price_model.MarketForecastClearingPrice.timestep
                == timestep
            )
            .first()
        )
    
    if not forecast_data_stored:
        raise HTTPException(status_code=404, detail="Market forecast not found")

    return forecast_data_stored

def get_market_forecasts_clearing_price(db: Session):
    market_forecasts_clearing_price = db.query(market_forecast_clearing_price_model.MarketForecastClearingPrice).all()
    return market_forecasts_clearing_price