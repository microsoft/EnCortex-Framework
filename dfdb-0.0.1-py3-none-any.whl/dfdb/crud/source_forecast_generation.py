from datetime import datetime
import typing as t
from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from dfdb.models import source_forecast_generation as source_forecast_generation_model
from dfdb.schemas.source_forecast_generation import SourceForecastGeneration, SourceForecastGenerationCreate

def create_source_forecast_generation(db: Session, source_forecast_generation: SourceForecastGenerationCreate):
    db_source_forecast_generation = source_forecast_generation_model.SourceForecastGeneration (**source_forecast_generation.dict())
    db.add(db_source_forecast_generation)
    db.commit()
    return db_source_forecast_generation


def get_source_forecast_generation(db: Session, source_id: int, timestamp: datetime, timestep: int):
    
    forecast_data_stored = (
            db.query(
                source_forecast_generation_model.SourceForecastGeneration
            )
            .filter(
                source_forecast_generation_model.SourceForecastGeneration.source_id
                == source_id,
                 source_forecast_generation_model.SourceForecastGeneration.start_timestamp
                == timestamp,
                 source_forecast_generation_model.SourceForecastGeneration.timestep
                == timestep
            )
            .first()
        )
    
    if not forecast_data_stored:
        raise HTTPException(status_code=404, detail="source forecast not found")

    return forecast_data_stored

def get_source_forecasts_generation(db: Session):
    source_forecasts_generation = db.query(source_forecast_generation_model.SourceForecastGeneration).all()
    return source_forecasts_generation