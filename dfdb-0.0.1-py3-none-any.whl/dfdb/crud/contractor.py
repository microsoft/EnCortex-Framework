import typing as t

from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from dfdb.models import contractor as contractor_
from dfdb.schemas.contractor import (
    ContractorCreate,
    ContractorEdit,
    ContractorOut,
)


def get_contractor(db: Session, id: int):
    contractor = (
        db.query(contractor_.Contract)
        .filter(contractor_.Contract.id == id)
        .first()
    )
    if not contractor:
        raise HTTPException(status_code=404, detail="Contractor not found")

    return contractor


def create_contractor(db: Session, contractor: ContractorCreate):
    contractor = contractor_.Contract(
        source_id=contractor.source_id,
        contractor_id=contractor.contractor_id,
        start_time=contractor.start_time,
        end_time=contractor.end_time,
    )
    db.add(contractor)
    db.commit()
    db.refresh(contractor)
    return contractor


def edit_contractor(
    db: Session, contractor_id: int, contractor: ContractorEdit
):
    db_contractor = get_contractor(db, contractor_id)
    if not db_contractor:
        raise HTTPException(
            status.HTTP_404_NOT_FOUND, detail="Contractor not found"
        )

    update_contractor = contractor.dict(exclude_unset=True)
    for key, value in update_contractor.items():
        setattr(db_contractor, key, value)

    db.add(db_contractor)
    db.commit()
    db.refresh(db_contractor)
    return db_contractor


def delete_contractor(db: Session, contractor_id: int):
    contractor = get_contractor(db, contractor_id)
    if not contractor:
        raise HTTPException(
            status.HTTP_404_NOT_FOUND, detail="Contractor not found"
        )

    db.delete(contractor)
    db.commit()
    return contractor
