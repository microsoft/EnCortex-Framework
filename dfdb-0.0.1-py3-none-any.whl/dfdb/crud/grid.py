import typing as t


from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from dfdb.models import grid as grid_model
from dfdb.schemas.grid import GridCreate, GridEdit, GridDelete, Grid


def create_grid(db: Session, grid: GridCreate):
    db_grid = grid_model.Grid(**grid.dict())
    db.add(db_grid)
    db.commit()
    return db_grid