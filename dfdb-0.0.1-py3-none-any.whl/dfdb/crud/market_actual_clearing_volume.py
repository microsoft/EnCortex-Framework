from datetime import datetime
import typing as t
from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from dfdb.models import market_actual_clearing_volume as market_actual_clearing_volume_model
from dfdb.schemas.market_actual_clearing_volume import MarketActualClearingVolume, MarketActualClearingVolumeCreate

def create_market_actual_clearing_volume(db: Session, market_actual_clearing_volume: MarketActualClearingVolumeCreate):
    db_market_actual_clearing_volume = market_actual_clearing_volume_model.MarketActualClearingVolume (**market_actual_clearing_volume.dict())
    db.add(db_market_actual_clearing_volume)
    db.commit()
    return db_market_actual_clearing_volume


def get_market_actual_clearing_volume(db: Session, market_id: int, timestamp: datetime, timestep: int):
    
    actual_data_stored = (
            db.query(
                market_actual_clearing_volume_model.MarketActualClearingVolume
            )
            .filter(
                market_actual_clearing_volume_model.MarketActualClearingVolume.market_id
                == market_id,
                 market_actual_clearing_volume_model.MarketActualClearingVolume.start_timestamp
                == timestamp,
                 market_actual_clearing_volume_model.MarketActualClearingVolume.timestep
                == timestep
            )
            .first()
        )
    
    if not actual_data_stored:
        raise HTTPException(status_code=404, detail="Market actual not found")

    return actual_data_stored

def get_market_actuals_clearing_volume(db: Session):
    market_actuals_clearing_volume = db.query(market_actual_clearing_volume_model.MarketActualClearingVolume).all()
    return market_actuals_clearing_volume