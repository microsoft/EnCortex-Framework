import typing as t

from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from dfdb.models import contractevent as contractevent_
from dfdb.schemas.contractevent import (
    ContractEventCreate,
    ContractEventEdit,
    ContractEvent,
    ContractEventOut,
    ContractEventDelete,
)


def get_contractevent(db: Session, id: int):
    contractevent = (
        db.query(contractevent_.ContractEvent)
        .filter(contractevent_.ContractEvent.id == id)
        .first()
    )
    if not contractevent:
        raise HTTPException(status_code=404, detail="ContractEvent not found")

    return contractevent


def get_contractevents(db: Session):
    contractevents = db.query(contractevent_.ContractEvent).all()
    return contractevents


def create_contractevent(db: Session, contractevent: ContractEventCreate):
    db_contractevent = contractevent_.ContractEvent(**contractevent.dict())
    db.add(db_contractevent)
    db.commit()
    db.refresh(db_contractevent)
    return db_contractevent


def edit_contractevent(db: Session, contractevent: ContractEventEdit):
    db_contractevent = get_contractevent(db, contractevent.id)

    update_contractevent = contractevent.dict(exclude_unset=True)
    for key, value in update_contractevent.items():
        setattr(db_contractevent, key, value)

    db.commit()
    db.refresh(db_contractevent)
    return db_contractevent


def delete_contractevent(db: Session, contractevent_id: int):
    db_contractevent = get_contractevent(db, contractevent_id)
    db.delete(db_contractevent)
    db.commit()
    return db_contractevent
