from datetime import datetime
import typing as t
from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from dfdb.models import grid_forecast_marginal_carbon_intensity as grid_forecast_marginal_carbon_intensity_model
from dfdb.schemas.grid_forecast_marginal_carbon_intensity import GridForecastMarginalCarbonIntensity, GridForecastMarginalCarbonIntensityCreate

def create_grid_forecast_marginal_carbon_intensity(db: Session, grid_forecast_marginal_carbon_intensity: GridForecastMarginalCarbonIntensityCreate):
    db_grid_forecast_marginal_carbon_intensity = grid_forecast_marginal_carbon_intensity_model.GridForecastMarginalCarbonIntensity (**grid_forecast_marginal_carbon_intensity.dict())
    db.add(db_grid_forecast_marginal_carbon_intensity)
    db.commit()
    return db_grid_forecast_marginal_carbon_intensity


def get_grid_forecast_marginal_carbon_intensity(db: Session, grid_id: int, timestamp: datetime, timestep: int):
    
    forecast_data_stored = (
            db.query(
                grid_forecast_marginal_carbon_intensity_model.GridForecastMarginalCarbonIntensity
            )
            .filter(
                grid_forecast_marginal_carbon_intensity_model.GridForecastMarginalCarbonIntensity.grid_id
                == grid_id,
                 grid_forecast_marginal_carbon_intensity_model.GridForecastMarginalCarbonIntensity.start_timestamp
                == timestamp,
                 grid_forecast_marginal_carbon_intensity_model.GridForecastMarginalCarbonIntensity.timestep
                == timestep
            )
            .first()
        )
    
    if not forecast_data_stored:
        raise HTTPException(status_code=404, detail="Grid forecast not found")

    return forecast_data_stored

def get_grid_forecasts_marginal_carbon_intensity(db: Session):
    grid_forecasts_marginal_carbon_intensity = db.query(grid_forecast_marginal_carbon_intensity_model.GridForecastMarginalCarbonIntensity).all()
    return grid_forecasts_marginal_carbon_intensity