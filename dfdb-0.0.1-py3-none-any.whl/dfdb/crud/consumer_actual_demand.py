from datetime import datetime
import typing as t
from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from dfdb.models import consumer_actual_demand as consumer_actual_demand_model
from dfdb.schemas.consumer_actual_demand import ConsumerActualDemand, ConsumerActualDemandCreate

def create_consumer_actual_demand(db: Session, consumer_actual_demand: ConsumerActualDemandCreate):
    db_consumer_actual_demand = consumer_actual_demand_model.ConsumerActualDemand (**consumer_actual_demand.dict())
    db.add(db_consumer_actual_demand)
    db.commit()
    return db_consumer_actual_demand


def get_consumer_actual_demand(db: Session, consumer_id: int, timestamp: datetime, timestep: int):
    
    actual_data_stored = (
            db.query(
                consumer_actual_demand_model.ConsumerActualDemand
            )
            .filter(
                consumer_actual_demand_model.ConsumerActualDemand.consumer_id
                == consumer_id,
                 consumer_actual_demand_model.ConsumerActualDemand.start_timestamp
                == timestamp,
                 consumer_actual_demand_model.ConsumerActualDemand.timestep
                == timestep
            )
            .first()
        )
    
    if not actual_data_stored:
        raise HTTPException(status_code=404, detail="consumer actual not found")

    return actual_data_stored

def get_consumer_actuals_demand(db: Session):
    consumer_actuals_demand = db.query(consumer_actual_demand_model.ConsumerActualDemand).all()
    return consumer_actuals_demand