from datetime import datetime
import typing as t

from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from dfdb.models import contractor_actual as contractor_actual_
from dfdb.schemas.contractor_actual import (
    ContractorActualCreate,
    ContractorActualEdit,
    ContractorActualOut,
    ContractorActual,
)


def get_contractor_actual_data(db: Session, contractor_actual_id: int):
    contractor_actual_data = (
        db.query(contractor_actual_.ContractorActual)
        .filter(contractor_actual_.ContractorActual.id == contractor_actual_id)
        .first()
    )
    if not contractor_actual_data:
        raise HTTPException(
            status_code=404, detail="Source Actual data not found"
        )

    return contractor_actual_data


def get_contractor_actual_data_by_time(
    db: Session, contractor_actual_time: datetime
):
    contractor_actual_data = (
        db.query(contractor_actual_.ContractorActual)
        .filter(
            contractor_actual_.ContractorActual.data_time
            == contractor_actual_time
        )
        .first()
    )
    if not contractor_actual_data:
        raise HTTPException(
            status_code=404, detail="Source Actual data not found"
        )

    return contractor_actual_data


def get_contractor_actual_data_before_time(
    db: Session, contractor_actual_time: datetime
):
    contractor_actual_data = db.query(
        contractor_actual_.ContractorActual
    ).filter(
        contractor_actual_.ContractorActual.data_time <= contractor_actual_time
    )
    if not contractor_actual_data:
        raise HTTPException(
            status_code=404,
            detail="Source Actual data not found before this time",
        )

    return contractor_actual_data


def get_contractor_actual_data_after_time(
    db: Session, contractor_actual_time: datetime
):
    contractor_actual_data = db.query(
        contractor_actual_.ContractorActual
    ).filter(
        contractor_actual_.ContractorActual.data_time >= contractor_actual_time
    )
    if not contractor_actual_data:
        raise HTTPException(
            status_code=404,
            detail="Source Actual data not found after this time",
        )

    return contractor_actual_data


def get_contractor_actual_data_interval_time(
    db: Session,
    contractor_actual_start_time: datetime,
    contractor_actual_end_time: datetime,
):
    contractor_actual_data = (
        db.query(contractor_actual_.ContractorActual)
        .filter(
            contractor_actual_.ContractorActual.data_time
            >= contractor_actual_start_time
        )
        .filter(
            contractor_actual_.ContractorActual.data_time
            <= contractor_actual_end_time
        )
    )
    if not contractor_actual_data:
        raise HTTPException(
            status_code=404,
            detail="Source Actual data not found in this tnterval",
        )

    return contractor_actual_data


def create_contractor_actual_data(
    db: Session, contractor_actual_data: t.Iterable, contractor_id: int
):
    contractor_actual_data = list(
        map(
            lambda data_point: contractor_actual_.SourceActual(
                data=data_point.data,
                data_time=data_point.time,
                source_id=contractor_id,
            ),
            contractor_actual_data,
        )
    )
    db.bulk_save_objects(contractor_actual_data)
    db.commit()
    return contractor_actual_data


def delete_contractor_actual_data(
    db: Session, contractor_actual_ids: t.List[int]
):
    contractor_actual_data = db.query(
        contractor_actual_.ContractorActual
    ).filter(contractor_actual_.ContractorActual.id.in_(contractor_actual_ids))
    if not contractor_actual_data:
        raise HTTPException(
            status_code=404, detail="Source Actual data not found"
        )

    db.delete(contractor_actual_data)
    db.commit()
    return contractor_actual_data
