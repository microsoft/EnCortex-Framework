from datetime import datetime
import typing as t
from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from dfdb.models import consumer_forecast_demand as consumer_forecast_demand_model
from dfdb.schemas.consumer_forecast_demand import ConsumerForecastDemand, ConsumerForecastDemandCreate

def create_consumer_forecast_demand(db: Session, consumer_forecast_demand: ConsumerForecastDemandCreate):
    db_consumer_forecast_demand = consumer_forecast_demand_model.ConsumerForecastDemand (**consumer_forecast_demand.dict())
    db.add(db_consumer_forecast_demand)
    db.commit()
    return db_consumer_forecast_demand


def get_consumer_forecast_demand(db: Session, consumer_id: int, timestamp: datetime, timestep: int):
    
    forecast_data_stored = (
            db.query(
                consumer_forecast_demand_model.ConsumerForecastDemand
            )
            .filter(
                consumer_forecast_demand_model.ConsumerForecastDemand.consumer_id
                == consumer_id,
                 consumer_forecast_demand_model.ConsumerForecastDemand.start_timestamp
                == timestamp,
                 consumer_forecast_demand_model.ConsumerForecastDemand.timestep
                == timestep
            )
            .first()
        )
    
    if not forecast_data_stored:
        raise HTTPException(status_code=404, detail="consumer forecast not found")

    return forecast_data_stored

def get_consumer_forecasts_demand(db: Session):
    consumer_forecasts_demand = db.query(consumer_forecast_demand_model.ConsumerForecastDemand).all()
    return consumer_forecasts_demand