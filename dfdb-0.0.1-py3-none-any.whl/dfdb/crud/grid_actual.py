from datetime import datetime
import typing as t

from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from dfdb.models import grid_actual_marginal_carbon_intensity as grid_actual_marginal_carbon_intensity_model
from dfdb.schemas.source_actual import (
    SourceActualCreate,
    SourceActualEdit,
    SourceActualOut,
    SourceActual,
)



def get_grid_actual_marginal_carbon_intensity(db: Session, grid_actual_marginal_carbon_intensity_id: int):
    grid_actual_marginal_carbon_emission = (
        db.query(grid_actual_marginal_carbon_intensity_model.GridActualMarginalCarbonIntensity)
        .filter(grid_actual_marginal_carbon_intensity_model.GridActualMarginalCarbonIntensity.id == grid_actual_marginal_carbon_intensity_id)
        .first()
    )

    if not grid_actual_marginal_carbon_emission:
        raise HTTPException(
            status_code=404, detail="Grid Actual marginal carbon emission data not found"
        )

    return grid_actual_marginal_carbon_emission

def get_grid_actual_marginal_carbon_intensity(db: Session, grid_id: int, timestamp:  datetime, timestep: int):

    grid_actual_marginal_carbon_intensity = (
        db.query(
            grid_actual_marginal_carbon_intensity_model.GridActualMarginalCarbonIntensity
        )
        .filter(
            grid_actual_marginal_carbon_intensity_model.GridActualMarginalCarbonIntensity.grid_id
            == grid_id,
                grid_actual_marginal_carbon_intensity_model.GridActualMarginalCarbonIntensity.actual_start_timestamp
            == timestamp,
                grid_actual_marginal_carbon_intensity_model.GridActualMarginalCarbonIntensity.actual_timestep
            == timestep
        )
        .first()
    )

    if not grid_actual_marginal_carbon_intensity:
        raise HTTPException(
            status_code=404, detail="Grid Actual marginal carbon intensity data not found"
        )

    return grid_actual_marginal_carbon_intensity

def get_grid_actual_marginal_carbon_intensity(db: Session, grid_id: int, timestamp:  datetime):

    grid_actual_marginal_carbon_intensity = (
        db.query(
            grid_actual_marginal_carbon_intensity_model.GridActualMarginalCarbonIntensity
        )
        .filter(
            grid_actual_marginal_carbon_intensity_model.GridActualMarginalCarbonIntensity.grid_id
            == grid_id,
                grid_actual_marginal_carbon_intensity_model.GridActualMarginalCarbonIntensity.actual_start_timestamp
            == timestamp
        )
    )

    if not grid_actual_marginal_carbon_intensity:
        raise HTTPException(
            status_code=404, detail="Grid Actual marginal carbon emission data not found"
        )

    return grid_actual_marginal_carbon_intensity


def get_grid_actual_marginal_carbon_intensity_for_interval_time(
    db: Session,
    grid_id: int,
    start_time: datetime,
    end_time: datetime,
    timestep: int = 15
):
    grid_actual_marginal_carbon_intensity_data = (
        db.query(grid_actual_marginal_carbon_intensity_model.GridActualMarginalCarbonIntensityl)
        .filter(grid_actual_marginal_carbon_intensity_model.GridActualMarginalCarbonIntensity.actual_start_timestamp >= start_time)
        .filter(grid_actual_marginal_carbon_intensity_model.GridActualMarginalCarbonIntensity.actual_start_timestamp <= end_time)
        .filter(grid_actual_marginal_carbon_intensity_model.GridActualMarginalCarbonIntensity.actual_timestep <= timestep)
    )

    if not grid_actual_marginal_carbon_intensity_data:
        raise HTTPException(
            status_code=404,
            detail="Grid actual marginal carbon emission data not found in this interval",
        )

    return grid_actual_marginal_carbon_intensity_data



def get_source_actual_data_interval_time(
    db: Session,
    source_actual_start_time: datetime,
    source_actual_end_time: datetime,
):
    source_actual_data = (
        db.query(source_actual_.SourceActual)
        .filter(
            source_actual_.SourceActual.data_time >= source_actual_start_time
        )
        .filter(source_actual_.SourceActual.data_time <= source_actual_end_time)
    )
    if not source_actual_data:
        raise HTTPException(
            status_code=404,
            detail="Source Actual data not found in this tnterval",
        )

    return source_actual_data


def create_source_actual_data(
    db: Session, source_actual_data: t.Iterable, source_id: int
):
    source_actual_data = list(
        map(
            lambda data_point: source_actual_.SourceActual(
                data=data_point.data,
                data_time=data_point.time,
                source_id=source_id,
            ),
            source_actual_data,
        )
    )
    db.bulk_save_objects(source_actual_data)
    db.commit()
    return source_actual_data


def delete_source_actual_data(db: Session, source_actual_ids: t.List[int]):
    source_actual_data = db.query(source_actual_.SourceActual).filter(
        source_actual_.SourceActual.id.in_(source_actual_ids)
    )
    if not source_actual_data:
        raise HTTPException(
            status_code=404, detail="Source Actual data not found"
        )

    db.delete(source_actual_data)
    db.commit()
    return source_actual_data
