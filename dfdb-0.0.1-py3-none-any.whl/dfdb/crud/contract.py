import typing as t

from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from dfdb.models import contract as contract_
from dfdb.schemas.contract import ContractCreate, ContractEdit, ContractOut


def get_contract(db: Session, source_id: int):
    contract = (
        db.query(contract_.Contract)
        .filter(contract_.Contract.source_id == source_id)
        .first()
    )
    if not contract:
        raise HTTPException(status_code=404, detail="Contract not found")

    return contract


def get_contracts(db: Session):
    contracts = db.query(contract_.Contract).all()
    return contracts


def get_contract_by_contractor(db: Session, contractor_id: int):
    contract = (
        db.query(contract_.Contract)
        .filter(contract_.Contract.source_id == contractor_id)
        .first()
    )
    if not contract:
        raise HTTPException(status_code=404, detail="Contract not found")

    return contract


def create_contract(db: Session, contracts: t.List[ContractCreate]):
    last_contract = (
        db.query(contract_.Contract)
        .order_by(contract_.Contract.id.desc())
        .first()
    )
    for contract in contracts:
        db_contract = contract_.Contract(
            source_id=contract.source_id,
            contractor_id=contract.contractor_id,
            start_time=contract.start_time,
            end_time=contract.end_time,
            contract_id=last_contract.id + 1 if last_contract else 1,
        )
        db.add(db_contract)
        db.commit()
        db.refresh(db_contract)
    return contracts


def edit_contract(db: Session, contract: ContractEdit):
    db_contract = get_contract(db, contract.source_id)

    update_contract = contract.dict(exclude_unset=True)
    for key, value in update_contract.items():
        setattr(db_contract, key, value)

    db.commit()
    db.refresh(db_contract)
    return db_contract


def delete_contract(db: Session, source_id: int):
    db_contract = get_contract(db, source_id)
    db.delete(db_contract)
    db.commit()
    return db_contract
