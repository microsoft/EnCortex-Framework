from datetime import datetime
import typing as t

from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from dfdb.models import contractor_forecast as contractor_forecast_
from dfdb.schemas.contractor_forecast import (
    ContractorForecastCreate,
    ContractorForecastEdit,
    ContractorForecastOut,
    ContractorForecast,
)


def get_contractor_forecast_data(db: Session, contractor_forecast_id: int):
    contractor_forecast_data = (
        db.query(contractor_forecast_.ContractorForecast)
        .filter(
            contractor_forecast_.ContractorForecast.id == contractor_forecast_id
        )
        .first()
    )
    if not contractor_forecast_data:
        raise HTTPException(
            status_code=404, detail="Source Forecast data not found"
        )

    return contractor_forecast_data


def get_contractor_forecast_data_by_time(
    db: Session, contractor_forecast_time: datetime
):
    contractor_forecast_data = (
        db.query(contractor_forecast_.ContractorForecast)
        .filter(
            contractor_forecast_.ContractorForecast.data_time
            == contractor_forecast_time
        )
        .first()
    )
    if not contractor_forecast_data:
        raise HTTPException(
            status_code=404, detail="Source Forecast data not found"
        )

    return contractor_forecast_data


def get_contractor_forecast_data_before_time(
    db: Session, contractor_forecast_time: datetime
):
    contractor_forecast_data = db.query(
        contractor_forecast_.ContractorForecast
    ).filter(
        contractor_forecast_.ContractorForecast.data_time
        <= contractor_forecast_time
    )
    if not contractor_forecast_data:
        raise HTTPException(
            status_code=404,
            detail="Source Forecast data not found before this time",
        )

    return contractor_forecast_data


def get_contractor_forecast_data_after_time(
    db: Session, contractor_forecast_time: datetime
):
    contractor_forecast_data = db.query(
        contractor_forecast_.ContractorForecast
    ).filter(
        contractor_forecast_.ContractorForecast.data_time
        >= contractor_forecast_time
    )
    if not contractor_forecast_data:
        raise HTTPException(
            status_code=404,
            detail="Source Forecast data not found after this time",
        )

    return contractor_forecast_data


def get_contractor_forecast_data_interval_time(
    db: Session,
    contractor_forecast_start_time: datetime,
    contractor_forecast_end_time: datetime,
):
    contractor_forecast_data = (
        db.query(contractor_forecast_.ContractorForecast)
        .filter(
            contractor_forecast_.ContractorForecast.data_time
            >= contractor_forecast_start_time
        )
        .filter(
            contractor_forecast_.ContractorForecast.data_time
            <= contractor_forecast_end_time
        )
    )
    if not contractor_forecast_data:
        raise HTTPException(
            status_code=404,
            detail="Source Forecast data not found in this tnterval",
        )

    return contractor_forecast_data


def create_contractor_forecast_data(
    db: Session, contractor_forecast_data: t.List[ContractorForecastCreate]
):
    for data_point in contractor_forecast_data:
        contractor_forecast_data = contractor_forecast_.ContractorForecast(
            data=data_point.data,
            data_time=data_point.data_time,
            source_id=data_point.source_id,
        )
        db.add(contractor_forecast_data)
        db.commit()
        db.refresh(contractor_forecast_data)

    return contractor_forecast_data


def create_contractor_forecast_data(
    db: Session, contractor_forecast_data: t.Iterable, contractor_id: int
):
    contractor_forecast_data = list(
        map(
            lambda data_point: contractor_forecast_.Sourceforecast(
                data=data_point.data,
                data_time=data_point.time,
                source_id=contractor_id,
            ),
            contractor_forecast_data,
        )
    )
    db.bulk_save_objects(contractor_forecast_data)
    db.commit()
    return contractor_forecast_data


def delete_contractor_forecast_data(
    db: Session, contractor_forecast_ids: t.List[int]
):
    contractor_forecast_data = db.query(
        contractor_forecast_.ContractorForecast
    ).filter(
        contractor_forecast_.ContractorForecast.id.in_(contractor_forecast_ids)
    )
    if not contractor_forecast_data:
        raise HTTPException(
            status_code=404, detail="Source Forecast data not found"
        )

    db.delete(contractor_forecast_data)
    db.commit()
    return contractor_forecast_data
