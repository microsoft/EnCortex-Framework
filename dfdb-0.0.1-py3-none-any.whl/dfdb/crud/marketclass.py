import typing as t

from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from dfdb.models import marketclass as marketclass_model
from dfdb.schemas.marketclass import (
    MarketClassCreate,
    MarketClassEdit,
    MarketClass,
    MarketClassOut,
    MarketClassDelete,
)


def get_marketclass(db: Session, id: int):
    marketclass = (
        db.query(marketclass_model.MarketClass)
        .filter(marketclass_model.MarketClass.id == id)
        .first()
    )
    if not marketclass:
        raise HTTPException(status_code=404, detail="MarketClass not found")

    return marketclass


def get_marketclasses(db: Session):
    marketclasses = db.query(marketclass_model.MarketClass).all()
    return marketclasses


def create_marketclass(db: Session, marketclass: MarketClassCreate):
    db_marketclass = marketclass_model.MarketClass(**marketclass.dict())
    db.add(db_marketclass)
    db.commit()
    db.refresh(db_marketclass)
    return db_marketclass


def edit_marketclass(db: Session, marketclass: MarketClassEdit):
    db_marketclass = get_marketclass(db, marketclass.id)

    update_marketclass = marketclass.dict(exclude_unset=True)
    for key, value in update_marketclass.items():
        setattr(db_marketclass, key, value)

    db.commit()
    db.refresh(db_marketclass)
    return db_marketclass


def delete_marketclass(db: Session, marketclass_id: int):
    db_marketclass = get_marketclass(db, marketclass_id)
    db.delete(db_marketclass)
    db.commit()
    return db_marketclass
