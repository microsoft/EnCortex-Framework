import typing as t

from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from dfdb.models import sourceclass as sourceclass_
from dfdb.schemas.sourceclass import (
    SourceClassCreate,
    SourceClassEdit,
    SourceClassOut,
)


def get_sourceclass(db: Session, sourceclass_id: int):
    sourceclass = db.query(sourceclass_.SourceClass).filter(
        sourceclass_.SourceClass.id == sourceclass_id
    )
    if not sourceclass:
        raise HTTPException(status_code=404, detail="SourceClass not found")
    return sourceclass


def get_sourceclass_by_name(db: Session, sourceclass_name: str):
    sourceclass = db.query(sourceclass_.SourceClass).filter(
        sourceclass_.SourceClass.name == sourceclass_name
    )
    if not sourceclass:
        raise HTTPException(status_code=404, detail="SourceClass not found")
    return sourceclass


def get_sourceclasses(db: Session):
    sourceclass = db.query(sourceclass_.SourceClass).all()
    if not sourceclass:
        raise HTTPException(status_code=404, detail="No SourceClasses found")
    return sourceclass


def create_sourceclass(db: Session, sourceclass: SourceClassCreate):
    sourceclass = sourceclass_.SourceClass(
        name=sourceclass.name,
        description=sourceclass.description,
        action_count=sourceclass.action_count,
        action_to_description=sourceclass.action_to_description,
    )
    db.add(sourceclass)
    db.commit()
    db.refresh(sourceclass)
    return sourceclass


def edit_sourceclass(
    db: Session, sourceclass_id: int, sourceclass: SourceClassEdit
):
    db_sourceclass = get_sourceclass(db, sourceclass_id)
    if not db_sourceclass:
        raise HTTPException(
            status.HTTP_404_NOT_FOUND, detail="SourceClass not found"
        )
    update_data = sourceclass.dict(exclude_unset=True)
    for key, value in update_data.items():
        setattr(db_sourceclass, key, value)

    db.add(db_sourceclass)
    db.commit()
    db.refresh(db_sourceclass)
    return sourceclass


def delete_sourceclass(db: Session, sourceclass_id: int):
    sourceclass = get_sourceclass(db, sourceclass_id)
    if not sourceclass:
        raise HTTPException(
            status.HTTP_404_NOT_FOUND, detail="SourceClass not found"
        )

    db.delete(sourceclass)
    db.commit()
    return sourceclass
