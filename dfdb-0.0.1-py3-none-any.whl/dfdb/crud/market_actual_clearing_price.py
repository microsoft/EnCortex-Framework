from datetime import datetime
import typing as t
from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from dfdb.models import market_actual_clearing_price as market_actual_clearing_price_model
from dfdb.schemas.market_actual_clearing_price import MarketActualClearingPrice, MarketActualClearingPriceCreate

def create_market_actual_clearing_price(db: Session, market_actual_clearing_price: MarketActualClearingPriceCreate):
    db_market_actual_clearing_price = market_actual_clearing_price_model.MarketActualClearingPrice (**market_actual_clearing_price.dict())
    db.add(db_market_actual_clearing_price)
    db.commit()
    return db_market_actual_clearing_price


def get_market_actual_clearing_price(db: Session, market_id: int, timestamp: datetime, timestep: int):
    
    actual_data_stored = (
            db.query(
                market_actual_clearing_price_model.MarketActualClearingPrice
            )
            .filter(
                market_actual_clearing_price_model.MarketActualClearingPrice.market_id
                == market_id,
                 market_actual_clearing_price_model.MarketActualClearingPrice.start_timestamp
                == timestamp,
                 market_actual_clearing_price_model.MarketActualClearingPrice.timestep
                == timestep
            )
            .first()
        )
    
    if not actual_data_stored:
        raise HTTPException(status_code=404, detail="Market actual not found")

    return actual_data_stored

def get_market_actuals_clearing_price(db: Session):
    market_actuals_clearing_price = db.query(market_actual_clearing_price_model.MarketActualClearingPrice).all()
    return market_actuals_clearing_price