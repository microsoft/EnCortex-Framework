import typing as t

from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from dfdb.models import source as source_
from dfdb.schemas.source import SourceCreate, SourceEdit, SourceOut
from dfdb.crud.producer import get_producer


def get_source(db: Session, source_id: int):
    source = (
        db.query(source_.Source).filter(source_.Source.id == source_id).first()
    )
    if not source:
        raise HTTPException(status_code=404, detail="Source not found")
    return source


def get_source_by_producer(db: Session, producer_id: int):
    source = db.query(source_.Source).filter(
        source_.Source.producer_id == producer_id
    )
    if not source:
        raise HTTPException(status_code=404, detail="Source not found")
    return source


def create_source(
    db: Session, source: source_.Source, producer_id: int, source_class_id: int
):
    source = source_.Source(
        name=source.name,
        description=source.description,
        location=source.location,
        capacity=source.capacity,
        producer_id=producer_id,
        source_class_id=source_class_id,
    )
    db.add(source)
    db.commit()
    db.refresh(source)
    return source


def edit_source(db: Session, source_id: int, source: SourceEdit):
    db_source = get_source(db, source_id)
    if not db_source:
        raise HTTPException(
            status.HTTP_404_NOT_FOUND, detail="Source not found"
        )

    updated_source = source.dict(exclude_unset=True)
    for key, value in updated_source.items():
        setattr(db_source, key, value)

    db.add(db_source)
    db.commit()
    db.refresh(db_source)
    return db_source


def delete_source(db: Session, source_id: int):
    source = get_producer(source_id)
    if not source:
        raise HTTPException(
            status.HTTP_404_NOT_FOUND, detail="Source not found"
        )

    db.delete(source)
    db.commit()
    return source
