import typing as t
from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from dfdb.models import market_forecasting as market_forecasting_model
from dfdb.schemas.market_forecasting import MarketForecasting, MarketForecastingEdit, MarketForecastingCreate

def create_market_forecasting_record(db: Session, market_forecasting: MarketForecastingCreate):
    db_market_forecasting = market_forecasting_model.MarketForecasting (**market_forecasting.dict())
    db.add(db_market_forecasting)
    db.commit()
    return db_market_forecasting


def get_market_forecasting_record(db: Session, entity_forecasting_id: int):
    market_forecasting_record = db.query(market_forecasting_model.MarketForecasting)\
        .filter(market_forecasting_model.MarketForecasting.entity_forecasting_id == entity_forecasting_id)\
        .first()
    
    if not market_forecasting_record:
        raise HTTPException(status_code=404, detail="market forecasting record not found")

    return market_forecasting_record

def get_market_forecasting_records(db: Session):
    market_forecasting_records = db.query(market_forecasting_model.MarketForecasting).all()
    return market_forecasting_records