# from .models import *

from .session import Base, get_db_as_context, engine, get_db_as_context
from contextlib import contextmanager
from sqlalchemy.orm import sessionmaker
from sqlalchemy import create_engine

from . import models, schemas, crud, session


in_memory_engine = create_engine("sqlite://")


@contextmanager
def get_in_memory_db() -> sessionmaker:
    SessionLocal = sessionmaker(
        autocommit=False, autoflush=False, bind=in_memory_engine
    )
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def create_in_memory_db():
    Base.metadata.create_all(in_memory_engine)