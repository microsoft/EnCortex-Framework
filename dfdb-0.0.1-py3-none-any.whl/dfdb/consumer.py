import typing as t

from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from dfdb.models import consumer as consumer_model
from dfdb.schemas.consumer import ConsumerCreate, ConsumerEdit, ConsumerOut
from dfdb.crud.producer import get_producer


def get_consumer(db: Session, consumer_id: int):
    consumer = (
        db.query(consumer_model.Consumer).filter(consumer_model.Consumer.id == consumer_id).first()
    )
    if not consumer:
        raise HTTPException(status_code=404, detail="Consumer not found")
    return consumer


def get_consumer_by_producer(db: Session, producer_id: int):
    consumer = db.query(consumer_model.Consumer).filter(
        consumer_model.Consumer.producer_id == producer_id
    )
    if not consumer:
        raise HTTPException(status_code=404, detail="Consumer not found")
    return consumer


def create_consumer(
    db: Session, consumer: consumer_model.Consumer, producer_id: int, consumer_class_id: int
):
    consumer = consumer_model.Consumer(
        name=consumer.name,
        description=consumer.description,
        location=consumer.location,
        capacity=consumer.capacity,
        producer_id=producer_id,
        consumer_class_id=consumer_class_id,
    )
    db.add(consumer)
    db.commit()
    db.refresh(consumer)
    return consumer


def edit_consumer(db: Session, consumer_id: int, consumer: ConsumerEdit):
    db_consumer = get_consumer(db, consumer_id)
    if not db_consumer:
        raise HTTPException(
            status.HTTP_404_NOT_FOUND, detail="Consumer not found"
        )

    updated_consumer = consumer.dict(exclude_unset=True)
    for key, value in updated_consumer.items():
        setattr(db_consumer, key, value)

    db.add(db_consumer)
    db.commit()
    db.refresh(db_consumer)
    return db_consumer


def delete_consumer(db: Session, consumer_id: int):
    consumer = get_producer(consumer_id)
    if not consumer:
        raise HTTPException(
            status.HTTP_404_NOT_FOUND, detail="Consumer not found"
        )

    db.delete(consumer)
    db.commit()
    return consumer
