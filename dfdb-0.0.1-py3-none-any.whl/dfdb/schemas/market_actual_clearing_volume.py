import typing as t
from datetime import datetime
from pydantic import BaseModel

class MarketActualClearingVolumeBase(BaseModel):
    entity_forecasting_id : int = None
    start_timestamp: datetime = None
    timestep: int = None
    clearing_volume: float = None

class MarketActualClearingVolumeCreate(MarketActualClearingVolumeBase):
    market_id: int
    class Config:
        orm_mode = True

class MarketActualClearingVolumeEdit(MarketActualClearingVolumeBase):
    market_id: int
    class Config:
        orm_mode = True

class MarketActualClearingVolumeDelete(MarketActualClearingVolumeBase):
    market_id: int
    class Config:
        orm_mode = True

class MarketActualClearingVolume(MarketActualClearingVolumeBase):
    market_id: int
    class Config:
        orm_mode = True
