import typing as t

from pydantic import BaseModel


class GridBase(BaseModel):
    name: str
    description: str
    location: str
    owner_id: int

class GridOut(GridBase):
    pass


class GridCreate(GridBase):
    class Config:
        orm_mode = True


class GridEdit(GridBase):
    class Config:
        orm_mode = True


class GridDelete(GridBase):
    class Config:
        orm_mode = True


class Grid(GridBase):
    id: t.Optional[int]

    class Config:
        orm_mode = True
