import typing as t
from datetime import datetime
from pydantic import BaseModel

class ForecastActualFormatBase(BaseModel):
    start_timestamp: datetime = None
    timestep: int = None
    horizon: int = None
    data: t.List[float] = []


class ForecastActualFormat(ForecastActualFormatBase):
    class Config:
        orm_mode = True