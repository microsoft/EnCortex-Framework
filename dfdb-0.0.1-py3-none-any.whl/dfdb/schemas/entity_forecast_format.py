import typing as t
from datetime import datetime

from pydantic import BaseModel


class ForecastFormatBase(BaseModel):
    start_timestamp: datetime = None
    horizon: int = None
    timestep: int = None
    bid_end_timestamp: datetime = None

class ForecastFormat(ForecastFormatBase):
    class Config:
        orm_mode = True

class ForecastFormatList(BaseModel):
    forecast_format_list : t.List[ForecastFormat]  = []
    class Config:
        orm_mode = True

class ForecastFormatCronBase(BaseModel):
    start_timestamp: datetime = None
    cron_schedule: str = ""

class ForecastFormatCron(ForecastFormatCronBase):
    class Config:
        orm_mode = True

class ForecastFormatCronList(BaseModel):
    forecast_format_cron_list : t.List[ForecastFormatCron]  = []
    class Config:
        orm_mode = True
