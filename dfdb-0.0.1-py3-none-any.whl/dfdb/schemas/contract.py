import datetime
import typing as t

from pydantic import BaseModel


class ContractBase(BaseModel):
    source_id: int
    contractor_id: int
    start_time: datetime.datetime
    end_time: datetime.datetime


class ContractOut(ContractBase):
    pass


class ContractCreate(ContractBase):
    class Config:
        orm_mode = True


class ContractEdit(ContractBase):
    class Config:
        orm_mode = True


class ContractDelete(ContractBase):
    class Config:
        orm_mode = True


class Contract(ContractBase):
    id: t.Optional[int]
    contract_id: t.Optional[int]

    class Config:
        orm_mode = True
