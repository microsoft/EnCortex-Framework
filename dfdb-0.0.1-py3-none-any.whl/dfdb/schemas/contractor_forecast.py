import typing as t
from datetime import datetime

from pydantic import BaseModel


class ContractorForecastBase(BaseModel):
    data: float
    data_time: datetime


class ContractorForecastOut(ContractorForecastBase):
    id: t.Optional[int]
    source_id: t.Optional[int]


class ContractorForecastCreate(ContractorForecastBase):
    class Config:
        orm_mode = True


class ContractorForecastEdit(ContractorForecastBase):
    class Config:
        orm_mode = True


class ContractorForecastDelete(ContractorForecastBase):
    class Config:
        orm_mode = True


class ContractorForecast(ContractorForecastBase):
    id: t.Optional[int]
    source_id: t.Optional[int]

    class Config:
        orm_mode = True
