import typing as t
from pydantic import BaseModel


class ConsumerBase(BaseModel):
    name: str
    description: str
    owner_id: int
    location: str

class ConsumerOut(ConsumerBase):
    pass


class ConsumerCreate(ConsumerBase):
    class Config:
        orm_mode = True


class ConsumerEdit(ConsumerBase):
    class Config:
        orm_mode = True


class ConsumerDelete(ConsumerBase):
    class Config:
        orm_mode = True


class Consumer(ConsumerBase):
    id: int

    class Config:
        orm_mode = True
