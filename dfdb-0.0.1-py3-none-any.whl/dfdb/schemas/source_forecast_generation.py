import typing as t
from datetime import datetime
from pydantic import BaseModel

class SourceForecastGenerationBase(BaseModel):
    entity_forecasting_id : int = None
    start_timestamp: datetime = None
    timestep: int = None
    generation : float = None
    uncertainty: dict = []

class SourceForecastGenerationCreate(SourceForecastGenerationBase):
    source_id: int
    class Config:
        orm_mode = True


class SourceForecastGenerationEdit(SourceForecastGenerationBase):
    source_id: int
    class Config:
        orm_mode = True


class SourceForecastGenerationDelete(SourceForecastGenerationBase):
    source_id: int
    class Config:
        orm_mode = True

class SourceForecastGeneration(SourceForecastGenerationBase):
    source_id: int
    class Config:
        orm_mode = True
