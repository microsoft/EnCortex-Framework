import typing as t
from pydantic import BaseModel


class ConsumerForecastingBase(BaseModel):
    consumer_id: int
    entity_forecasting_id: int

class ConsumerForecastingOut(ConsumerForecastingBase):
    pass

class ConsumerForecastingCreate(ConsumerForecastingBase):
    class Config:
        orm_mode = True


class ConsumerForecastingEdit(ConsumerForecastingBase):
    class Config:
        orm_mode = True


class ConsumerForecastingDelete(ConsumerForecastingBase):
    class Config:
        orm_mode = True


class ConsumerForecasting(ConsumerForecastingBase):
    id: t.Optional[int]

    class Config:
        orm_mode = True
