import typing as t
from datetime import datetime
from pydantic import BaseModel

class ConsumerActualDemandBase(BaseModel):
    entity_forecasting_id : int = None
    start_timestamp: datetime = None
    timestep: int = None
    demand : float = None
    marginal_carbon_intensity : float = None

class ConsumerActualDemandCreate(ConsumerActualDemandBase):
    consumer_id: int
    class Config:
        orm_mode = True


class ConsumerActualDemandEdit(ConsumerActualDemandBase):
    consumer_id: int
    class Config:
        orm_mode = True


class ConsumerActualDemandDelete(ConsumerActualDemandBase):
    consumer_id: int
    class Config:
        orm_mode = True

class ConsumerActualDemand(ConsumerActualDemandBase):
    consumer_id: int
    class Config:
        orm_mode = True
