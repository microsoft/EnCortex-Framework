import typing as t
from datetime import datetime
from pydantic import BaseModel

class MarketActualClearingPriceBase(BaseModel):
    entity_forecasting_id : int = None
    start_timestamp: datetime = None
    timestep: int = None
    clearing_price: float = None

class MarketActualClearingPriceCreate(MarketActualClearingPriceBase):
    market_id: int
    class Config:
        orm_mode = True

class MarketActualClearingPriceEdit(MarketActualClearingPriceBase):
    market_id: int
    class Config:
        orm_mode = True

class MarketActualClearingPriceDelete(MarketActualClearingPriceBase):
    market_id: int
    class Config:
        orm_mode = True

class MarketActualClearingPrice(MarketActualClearingPriceBase):
    market_id: int
    class Config:
        orm_mode = True
