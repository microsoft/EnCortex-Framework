import typing as t

from pydantic import BaseModel


class SourceBase(BaseModel):
    name: str
    description: str
    producer_id: int
    source_class_id: int
    location: str
    capacity: float


class SourceOut(SourceBase):
    pass


class SourceCreate(SourceBase):
    class Config:
        orm_mode = True


class SourceEdit(SourceBase):
    class Config:
        orm_mode = True


class SourceDelete(SourceBase):
    class Config:
        orm_mode = True


class Source(SourceBase):
    id: t.Optional[int]

    class Config:
        orm_mode = True
