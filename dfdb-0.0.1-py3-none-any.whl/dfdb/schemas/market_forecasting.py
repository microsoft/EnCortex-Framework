import typing as t

from pydantic import BaseModel


class MarketForecastingBase(BaseModel):
    market_id: int
    entity_forecasting_id: int

class MarketForecastingOut(MarketForecastingBase):
    pass


class MarketForecastingCreate(MarketForecastingBase):
    class Config:
        orm_mode = True


class MarketForecastingEdit(MarketForecastingBase):
    class Config:
        orm_mode = True


class MarketForecastingDelete(MarketForecastingBase):
    class Config:
        orm_mode = True


class MarketForecasting(MarketForecastingBase):
    id: t.Optional[int]

    class Config:
        orm_mode = True
