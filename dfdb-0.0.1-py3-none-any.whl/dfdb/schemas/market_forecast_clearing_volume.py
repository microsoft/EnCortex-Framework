import typing as t
from datetime import datetime
from pydantic import BaseModel

class MarketForecastClearingVolumeBase(BaseModel):
    entity_forecasting_id : int = None
    start_timestamp: datetime = None
    timestep: int = None
    clearing_volume: float = None
    uncertainty: dict = []

class MarketForecastClearingVolumeCreate(MarketForecastClearingVolumeBase):
    market_id: int
    class Config:
        orm_mode = True

class MarketForecastClearingVolumeEdit(MarketForecastClearingVolumeBase):
    market_id: int
    class Config:
        orm_mode = True

class MarketForecastClearingVolumeDelete(MarketForecastClearingVolumeBase):
    market_id: int
    class Config:
        orm_mode = True

class MarketForecastClearingVolume(MarketForecastClearingVolumeBase):
    market_id: int
    class Config:
        orm_mode = True
