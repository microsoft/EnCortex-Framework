import typing as t

from pydantic import BaseModel


class ProducerBase(BaseModel):
    name: str = None
    description: str = None
    location: str = None
    net_carbon_emissions: float = None
    profit: float = None


class ProducerOut(ProducerBase):
    is_active: bool = True
    owner_id: int = None
    email: str


class ProducerCreate(ProducerBase):
    class Config:
        orm_mode = True


class ProducerEdit(ProducerBase):
    class Config:
        orm_mode = True


class Producer(ProducerBase):
    id: int
    is_active: bool = True
    owner_id: int = None
    email: str

    class Config:
        orm_mode = True
