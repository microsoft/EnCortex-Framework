import typing as t

from pydantic import BaseModel


class ContractorBase(BaseModel):
    name: str
    description: str
    location: str
    requirement: float
    owner_id: int


class ContractorOut(ContractorBase):
    pass


class ContractorCreate(ContractorBase):
    class Config:
        orm_mode = True


class ContractorEdit(ContractorBase):
    class Config:
        orm_mode = True


class ContractorDelete(ContractorBase):
    class Config:
        orm_mode = True


class Contractor(ContractorBase):
    id: t.Optional[int]

    class Config:
        orm_mode = True
