import typing as t

from pydantic import BaseModel


class ForecasterBase(BaseModel):
    name: str
    description: str
    location: str
    owner_id: int

class ForecasterOut(ForecasterBase):
    pass


class ForecasterCreate(ForecasterBase):
    class Config:
        orm_mode = True


class ForecasterEdit(ForecasterBase):
    class Config:
        orm_mode = True


class ForecasterDelete(ForecasterBase):
    class Config:
        orm_mode = True


class Forecaster(ForecasterBase):
    id: t.Optional[int]

    class Config:
        orm_mode = True
