from pydantic import BaseModel

import typing as t


class MarketBase(BaseModel):
    market_class_id: int
    name: str
    owner_id : int

class MarketOut(MarketBase):
    pass


class MarketCreate(MarketBase):
    class Config:
        orm_mode = True


class MarketEdit(MarketBase):
    class Config:
        orm_mode = True


class MarketDelete(MarketBase):
    id: t.Optional[int]

    class Config:
        orm_mode = True


class Market(MarketBase):
    id: t.Optional[int]

    class Config:
        orm_mode = True
