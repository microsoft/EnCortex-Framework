from datetime import datetime
from pydantic import BaseModel

import typing as t


class MarketClassBase(BaseModel):
    name: str
    bid_window_interval: int
    bid_window_start_time: str
    bid_window_end_time: str


class MarketClassOut(MarketClassBase):
    class Config:
        orm_mode = True


class MarketClassCreate(MarketClassBase):
    class Config:
        orm_mode = True


class MarketClassEdit(MarketClassBase):
    class Config:
        orm_mode = True


class MarketClassDelete(MarketClassBase):
    class Config:
        orm_mode = True


class MarketClass(MarketClassBase):
    id: t.Optional[int]

    class Config:
        orm_mode = True
