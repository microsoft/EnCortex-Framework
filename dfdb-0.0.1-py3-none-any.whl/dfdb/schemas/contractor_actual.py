import typing as t
from datetime import datetime

from pydantic import BaseModel


class ContractorActualBase(BaseModel):
    data: float
    data_time: datetime


class ContractorActualOut(ContractorActualBase):
    id: t.Optional[int]
    source_id: t.Optional[int]


class ContractorActualCreate(ContractorActualBase):
    class Config:
        orm_mode = True


class ContractorActualEdit(ContractorActualBase):
    class Config:
        orm_mode = True


class ContractorActualDelete(ContractorActualBase):
    class Config:
        orm_mode = True


class ContractorActual(ContractorActualBase):
    id: t.Optional[int]
    source_id: t.Optional[int]

    class Config:
        orm_mode = True
