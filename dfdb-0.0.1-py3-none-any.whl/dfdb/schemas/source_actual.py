import typing as t
from datetime import datetime

from pydantic import BaseModel


class SourceActualBase(BaseModel):
    data: float
    data_time: datetime


class SourceActualOut(SourceActualBase):
    id: t.Optional[int]
    source_id: t.Optional[int]


class SourceActualCreate(SourceActualBase):
    source_id: int

    class Config:
        orm_mode = True


class SourceActualEdit(SourceActualBase):
    class Config:
        orm_mode = True


class SourceActualDelete(SourceActualBase):
    class Config:
        orm_mode = True


class SourceActual(SourceActualBase):
    id: t.Optional[int]
    source_id: t.Optional[int]

    class Config:
        orm_mode = True
