import typing as t

from pydantic import BaseModel, Json


class SourceClassBase(BaseModel):
    name: str
    description: str
    action_count: int
    action_to_description: dict


class SourceClassOut(SourceClassBase):
    pass


class SourceClassCreate(SourceClassBase):
    class Config:
        orm_mode = True


class SourceClassEdit(SourceClassBase):
    class Config:
        orm_mode = True


class SourceClassDelete(SourceClassBase):
    class Config:
        orm_mode = True


class SourceClass(SourceClassBase):
    id: t.Optional[int]

    class Config:
        orm_mode = True
