import typing as t

from pydantic import BaseModel


class SourceForecastingBase(BaseModel):
    source_id: int
    entity_forecasting_id: int

class SourceForecastingOut(SourceForecastingBase):
    pass


class SourceForecastingCreate(SourceForecastingBase):
    class Config:
        orm_mode = True


class SourceForecastingEdit(SourceForecastingBase):
    class Config:
        orm_mode = True


class SourceForecastingDelete(SourceForecastingBase):
    class Config:
        orm_mode = True


class SourceForecasting(SourceForecastingBase):
    id: t.Optional[int]

    class Config:
        orm_mode = True
