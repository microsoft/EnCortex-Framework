from pydantic import BaseModel

import typing as t


class ContractEventBase(BaseModel):
    action: t.Dict[str, t.Any]
    timestamp: t.Optional[str]
    penalty: t.Optional[float]
    supplied: t.Optional[float]
    actual: t.Optional[float]


class ContractEventOut(ContractEventBase):
    pass


class ContractEventCreate(ContractEventBase):
    class Config:
        orm_mode = True


class ContractEventEdit(ContractEventBase):
    class Config:
        orm_mode = True


class ContractEventDelete(ContractEventBase):
    class Config:
        orm_mode = True


class ContractEvent(ContractEventBase):
    id: t.Optional[int]
    contract_id: t.Optional[int]

    class Config:
        orm_mode = True
