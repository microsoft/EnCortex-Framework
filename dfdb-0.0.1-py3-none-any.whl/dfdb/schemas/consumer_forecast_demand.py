import typing as t
from datetime import datetime
from pydantic import BaseModel

class ConsumerForecastDemandBase(BaseModel):
    entity_forecasting_id : int = None
    start_timestamp: datetime = None
    timestep: int = None
    demand : float = None
    uncertainty: dict = []

class ConsumerForecastDemandCreate(ConsumerForecastDemandBase):
    consumer_id: int
    class Config:
        orm_mode = True


class ConsumerForecastDemandEdit(ConsumerForecastDemandBase):
    consumer_id: int
    class Config:
        orm_mode = True


class ConsumerForecastDemandDelete(ConsumerForecastDemandBase):
    consumer_id: int
    class Config:
        orm_mode = True

class ConsumerForecastDemand(ConsumerForecastDemandBase):
    consumer_id: int
    class Config:
        orm_mode = True
