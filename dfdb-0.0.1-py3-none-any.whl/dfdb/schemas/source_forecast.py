import typing as t
from datetime import datetime

from pydantic import BaseModel


class SourceForecastBase(BaseModel):
    data: float
    data_time: datetime


class SourceForecastOut(SourceForecastBase):
    id: t.Optional[int]
    source_id: t.Optional[int]


class SourceForecastCreate(SourceForecastBase):
    class Config:
        orm_mode = True


class SourceForecastEdit(SourceForecastBase):
    class Config:
        orm_mode = True


class SourceForecastDelete(SourceForecastBase):
    class Config:
        orm_mode = True


class SourceForecast(SourceForecastBase):
    id: t.Optional[int]
    source_id: t.Optional[int]

    class Config:
        orm_mode = True
