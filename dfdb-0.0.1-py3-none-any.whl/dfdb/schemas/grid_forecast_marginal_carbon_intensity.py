import typing as t
from datetime import datetime
from pydantic import BaseModel

class GridForecastMarginalCarbonIntensityBase(BaseModel):
    entity_forecasting_id : int = None
    start_timestamp: datetime = None
    timestep: int = None
    marginal_carbon_intensity: float = None
    uncertainty: dict = []

class GridForecastMarginalCarbonIntensityCreate(GridForecastMarginalCarbonIntensityBase):
    market_id: int
    class Config:
        orm_mode = True


class GridForecastMarginalCarbonIntensityEdit(GridForecastMarginalCarbonIntensityBase):
    market_id: int
    class Config:
        orm_mode = True


class GridForecastMarginalCarbonIntensityDelete(GridForecastMarginalCarbonIntensityBase):
    market_id: int
    class Config:
        orm_mode = True

class GridForecastMarginalCarbonIntensity(GridForecastMarginalCarbonIntensityBase):
    market_id: int
    class Config:
        orm_mode = True
