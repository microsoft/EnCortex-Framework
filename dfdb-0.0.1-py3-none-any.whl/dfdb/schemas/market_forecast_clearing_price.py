import typing as t
from datetime import datetime
from pydantic import BaseModel

class MarketForecastClearingPriceBase(BaseModel):
    entity_forecasting_id : int = None
    start_timestamp: datetime = None
    timestep: int = None
    clearing_price: float = None
    uncertainty: dict = []

class MarketForecastClearingPriceCreate(MarketForecastClearingPriceBase):
    market_id: int
    class Config:
        orm_mode = True

class MarketForecastClearingPriceEdit(MarketForecastClearingPriceBase):
    market_id: int
    class Config:
        orm_mode = True

class MarketForecastClearingPriceDelete(MarketForecastClearingPriceBase):
    market_id: int
    class Config:
        orm_mode = True

class MarketForecastClearingPrice(MarketForecastClearingPriceBase):
    market_id: int
    class Config:
        orm_mode = True
