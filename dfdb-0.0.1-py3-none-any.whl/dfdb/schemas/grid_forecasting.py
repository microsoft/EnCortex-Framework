import typing as t

from pydantic import BaseModel


class GridForecastingBase(BaseModel):
    grid_id: int
    entity_forecasting_id: int

class GridForecastingOut(GridForecastingBase):
    pass


class GridForecastingCreate(GridForecastingBase):
    class Config:
        orm_mode = True


class GridForecastingEdit(GridForecastingBase):
    class Config:
        orm_mode = True


class GridForecastingDelete(GridForecastingBase):
    class Config:
        orm_mode = True


class GridForecasting(GridForecastingBase):
    id: t.Optional[int]

    class Config:
        orm_mode = True
