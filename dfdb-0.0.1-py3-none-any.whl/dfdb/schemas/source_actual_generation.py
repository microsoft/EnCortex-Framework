import typing as t
from datetime import datetime
from pydantic import BaseModel

class SourceActualGenerationBase(BaseModel):
    entity_forecasting_id : int = None
    start_timestamp: datetime = None
    timestep: int = None
    generation : float = None

class SourceActualGenerationCreate(SourceActualGenerationBase):
    source_id: int
    class Config:
        orm_mode = True


class SourceActualGenerationEdit(SourceActualGenerationBase):
    source_id: int
    class Config:
        orm_mode = True


class SourceActualGenerationDelete(SourceActualGenerationBase):
    source_id: int
    class Config:
        orm_mode = True

class SourceActualGeneration(SourceActualGenerationBase):
    source_id: int
    class Config:
        orm_mode = True
