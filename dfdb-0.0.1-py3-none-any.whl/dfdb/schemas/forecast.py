from datetime import datetime
import typing as t
from pydantic import BaseModel

class ForecastBase(BaseModel):
    start_timestamp: datetime = None
    timestep: int = None
    horizon: int = None
    data: t.List[float] = []
    uncertainty: t.Dict[str, t.List[float]] = {}


class Forecast(ForecastBase):
    class Config:
        orm_mode = True