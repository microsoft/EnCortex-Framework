from sqlalchemy import (
    Boolean,
    Column,
    DateTime,
    Float,
    ForeignKey,
    Integer,
    String,
)
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func

from dfdb.session import Base


class ForecastingRegistration(Base):
    __tablename__ = "forecasting_registration"

    id = Column(Integer, index=True)
    forecaster_id = Column(Integer, ForeignKey("forecaster.id"))
    entity_forecasting_id = Column(Integer, primary_key = True)
    days_valid = Column(Integer)
    
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())