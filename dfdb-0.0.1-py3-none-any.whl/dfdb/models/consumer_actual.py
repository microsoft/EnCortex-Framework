from sqlalchemy import Column, ForeignKey
from dfdb.models.contractor_actual import ContractorActual
from sqlalchemy import Column, ForeignKey, Integer, String


class ConsumerActual(ContractorActual):
    __tablename__ = "consumeractual"

    id = Column(Integer, ForeignKey("contractoractual.id"), primary_key=True)

    __mapper_args__ = {
        "polymorphic_identity": "consumeractual",
    }
