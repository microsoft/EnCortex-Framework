from sqlalchemy import (
    JSON,
    Boolean,
    Column,
    DateTime,
    Float,
    ForeignKey,
    Integer,
    String,
)
from sqlalchemy.dialects.postgresql import ARRAY
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from sqlalchemy import UniqueConstraint

from dfdb.session import Base


class ContractorForecaster(Base):
    __tablename__ = "contractorforecaster"
    __table_args__ = (
        UniqueConstraint("contractor_id", "data_start_time", "data_end_time"),
    )

    id = Column(Integer, primary_key=True, index=True)
    contractor_id = Column(Integer, ForeignKey("contractor.id"))
    data_start_time = Column(DateTime(timezone=True), index=True)
    data_end_time = Column(DateTime(timezone=True), index=True)
    data = Column(JSON)
    data_type = Column(String)
