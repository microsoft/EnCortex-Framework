from sqlalchemy import Column, ForeignKey
from dfdb.models.contractor_forecaster import ContractorForecaster
from sqlalchemy import Column, ForeignKey, Integer, String


class MarketForecaster(ContractorForecaster):
    __tablename__ = "marketforecaster"

    id = Column(
        Integer, ForeignKey("contractorforecaster.id"), primary_key=True
    )

    __mapper_args__ = {
        "polymorphic_identity": "marketforecaster",
    }
