from sqlalchemy import Column, ForeignKey
from dfdb.models.contractor_actual import ContractorActual
from sqlalchemy import Column, ForeignKey, Integer, String


class MarketActual(ContractorActual):
    __tablename__ = "marketactual"

    id = Column(Integer, ForeignKey("contractoractual.id"), primary_key=True)

    __mapper_args__ = {
        "polymorphic_identity": "marketactual",
    }
