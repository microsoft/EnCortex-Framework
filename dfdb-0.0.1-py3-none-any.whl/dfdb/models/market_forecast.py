from sqlalchemy import Column, ForeignKey
from dfdb.models.contractor_forecast import ContractorForecast
from sqlalchemy import Column, ForeignKey, Integer, String


class MarketForecast(ContractorForecast):
    __tablename__ = "marketforecast"

    id = Column(Integer, ForeignKey("contractorforecast.id"), primary_key=True)

    __mapper_args__ = {
        "polymorphic_identity": "marketforecast",
    }
