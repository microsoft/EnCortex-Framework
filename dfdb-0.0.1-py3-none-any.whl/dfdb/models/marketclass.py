from sqlalchemy import (
    Boolean,
    Column,
    DateTime,
    Time,
    Float,
    ForeignKey,
    Integer,
    String,
)
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func

from dfdb.session import Base


class MarketClass(Base):
    __tablename__ = "marketclass"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String)
    description = Column(String)

    bid_window_interval = Column(Integer)
    bid_window_start_time = Column(String)
    bid_window_end_time = Column(String)

