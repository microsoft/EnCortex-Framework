from sqlalchemy import (
    JSON,
    Boolean,
    Column,
    DateTime,
    Float,
    ForeignKey,
    Integer,
    String,
    PrimaryKeyConstraint,
)
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from sqlalchemy import UniqueConstraint

from dfdb.session import Base


class SourceForecastGeneration(Base):
    __tablename__ = "source_forecast_generation"
    __table_args__ = (
        PrimaryKeyConstraint("source_id", "start_timestamp", "timestep"),
        {},
    )

    id = Column(Integer, index=True)

    source_id = Column(Integer, ForeignKey("source.id"), primary_key=True)
    entity_forecasting_id = Column(Integer, ForeignKey("source_forecasting.entity_forecasting_id"))
    
    start_timestamp = Column(DateTime(timezone=True), primary_key=True)
    timestep = Column(Integer, primary_key=True)
    
    generation = Column(Float)
    uncertainty = Column(JSON)

    created_at = Column(DateTime(timezone=True), server_default = func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())