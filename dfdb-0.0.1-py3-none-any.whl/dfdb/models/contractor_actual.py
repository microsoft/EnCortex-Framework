from sqlalchemy import (
    JSON,
    Boolean,
    Column,
    DateTime,
    Float,
    ForeignKey,
    Integer,
    String,
)
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from sqlalchemy import UniqueConstraint

from dfdb.session import Base


class ContractorActual(Base):
    __tablename__ = "contractoractual"
    __table_args__ = (UniqueConstraint("contractor_id", "data_time"),)

    id = Column(Integer, primary_key=True, index=True)
    contractor_id = Column(Integer, ForeignKey("contractor.id"))
    data_time = Column(DateTime(timezone=True), index=True)
    data = Column(Float)
    data_type = Column(String)

