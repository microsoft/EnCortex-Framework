from sqlalchemy import (
    Boolean,
    Column,
    DateTime,
    Float,
    ForeignKey,
    Integer,
    PrimaryKeyConstraint,
    String,
)
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func

from dfdb.session import Base

class GridActualMarginalCarbonIntensity(Base):
    __tablename__ = "grid_actual_marginal_carbon_intensity"
    __tableargs__ = (
        PrimaryKeyConstraint("grid_id", "actual_start_timestamp", "actual_timestep"),
    )

    id = Column(Integer, index=True)
    
    grid_id = Column(Integer, ForeignKey("grid.id"), primary_key=True)
    entity_forecasting_id = Column(Integer)
    
    start_timestamp = Column(DateTime(timezone=True), primary_key=True)
    timestep = Column(Integer, primary_key=True)

    marginal_carbon_intensity = Column(Float)
    
    created_at = Column(DateTime(timezone=True), server_default = func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())