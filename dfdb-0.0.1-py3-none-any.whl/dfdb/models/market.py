from sqlalchemy import Column, ForeignKey, Integer, String, DateTime, Boolean, PrimaryKeyConstraint
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from dfdb.session import Base

class Market(Base):
    __tablename__ = "market"

    id = Column(Integer, primary_key=True, index=True)
    market_class_id = Column(Integer, ForeignKey("marketclass.id"))
    name = Column(String)
    owner_id = Column(Integer, ForeignKey("user.id"))

    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    is_active = Column(Boolean, default=True)

    