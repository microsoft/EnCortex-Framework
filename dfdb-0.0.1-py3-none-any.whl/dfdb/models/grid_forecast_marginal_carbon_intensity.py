from sqlalchemy import (
    Boolean,
    Column,
    DateTime,
    Float,
    ForeignKey,
    Integer,
    PrimaryKeyConstraint,
    String,
    JSON
)
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func

from dfdb.session import Base


class GridForecastMarginalCarbonIntensity(Base):

    __tablename__ = "grid_forecast_marginal_carbon_intensity"
    __table_args__ = (
        PrimaryKeyConstraint("grid_id", "start_timestamp", "timestep"),
        {},
    )

    id = Column(Integer, index=True)
    
    grid_id = Column(Integer, ForeignKey("grid.id"), primary_key=True)
    entity_forecasting_id = Column(Integer, ForeignKey("grid_forecasting.entity_forecasting_id"))

    start_timestamp = Column(DateTime(timezone=True), primary_key=True)
    timestep = Column(Integer, primary_key=True)

    marginal_carbon_intensity = Column(Float)
    uncertainty = Column(JSON)

    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
