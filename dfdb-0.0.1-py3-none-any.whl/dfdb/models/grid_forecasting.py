from sqlalchemy import (
    Boolean,
    Column,
    DateTime,
    Float,
    ForeignKey,
    Integer,
    String,
    PrimaryKeyConstraint
)
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func

from dfdb.session import Base


class GridForecasting(Base):
    __tablename__ = "grid_forecasting"
    __table_args__ = (
        PrimaryKeyConstraint("entity_forecasting_id"),
        {},
    )

    id = Column(Integer, index=True)
    grid_id = Column(Integer, ForeignKey("grid.id"))
    entity_forecasting_id = Column(Integer,  ForeignKey("forecasting_registration.entity_forecasting_id"), index=True, primary_key=True)

    is_live = Column(Boolean, default=True)
    is_active = Column(Boolean, default=True)

    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())