from sqlalchemy import (
    Boolean,
    Column,
    DateTime,
    Float,
    ForeignKey,
    Integer,
    PrimaryKeyConstraint,
    String,
)
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func

from dfdb.session import Base

class MarketActualMarginalCarbonIntensity(Base):
    __tablename__ = "market_actual_marginal_carbon_intensity"
    __tableargs__ = (
        PrimaryKeyConstraint("market_id", "start_timestamp", "timestep"),
    )

    id = Column(Integer, index=True)
    
    market_id = Column(Integer, ForeignKey("market.id"), primary_key=True)
    entity_forecasting_id = Column(Integer, ForeignKey("market_forecasting.entity_forecasting_id"))
    
    start_timestamp = Column(DateTime(timezone=True), primary_key=True)
    timestep = Column(Integer, primary_key=True)

    marginal_carbon_intensity = Column(Float)
    
    created_at = Column(DateTime(timezone=True), server_default = func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())