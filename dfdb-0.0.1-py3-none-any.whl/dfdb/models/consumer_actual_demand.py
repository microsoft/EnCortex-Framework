from sqlalchemy import (
    Boolean,
    Column,
    DateTime,
    Float,
    ForeignKey,
    Integer,
    PrimaryKeyConstraint,
    String,
)
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func

from dfdb.session import Base

class ConsumerActualDemand(Base):
    __tablename__ = "consumer_actual_demand"
    __tableargs__ = (
        PrimaryKeyConstraint("consumer_id", "start_timestamp", "timestep"),
    )

    id = Column(Integer, index=True)
    
    consumer_id = Column(Integer, ForeignKey("consumer.id"), primary_key=True)
    entity_forecasting_id = Column(Integer)
    
    start_timestamp = Column(DateTime(timezone=True), primary_key=True)
    timestep = Column(Integer, primary_key=True)

    demand = Column(Float)
    marginal_carbon_intensity = Column(Float)
    
    created_at = Column(DateTime(timezone=True), server_default = func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())