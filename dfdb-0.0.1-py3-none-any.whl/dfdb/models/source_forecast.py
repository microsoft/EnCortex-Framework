from sqlalchemy import (
    JSON,
    Boolean,
    Column,
    DateTime,
    Float,
    ForeignKey,
    Integer,
    String,
    UniqueConstraint,
)
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func

from dfdb.session import Base


class SourceForecast(Base):
    __tablename__ = "sourceforecast"
    __table_args__ = (UniqueConstraint("source_id", "data_time"),)

    id = Column(Integer, primary_key=True, index=True)
    source_id = Column(Integer, ForeignKey("source.id"))
    data_time = Column(DateTime(timezone=True), index=True)
    data = Column(Float)

