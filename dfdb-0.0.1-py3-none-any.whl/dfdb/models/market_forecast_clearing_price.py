from sqlalchemy import (
    Boolean,
    Column,
    DateTime,
    Float,
    ForeignKey,
    Integer,
    PrimaryKeyConstraint,
    String,
    JSON
)
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func

from dfdb.session import Base


class MarketForecastClearingPrice(Base):

    __tablename__ = "market_forecast_clearing_price"
    __table_args__ = (
        PrimaryKeyConstraint("market_id", "start_timestamp", "timestep"),
        {},
    )

    id = Column(Integer, index=True)
    
    market_id = Column(Integer, ForeignKey("market.id"), primary_key=True) #TODO: VB: Ask AA this
    entity_forecasting_id = Column(Integer, ForeignKey("market_forecasting.entity_forecasting_id"))

    start_timestamp = Column(DateTime(timezone=True), primary_key = True)
    timestep = Column(Integer, primary_key = True)

    clearing_price = Column(Float)
    uncertainty = Column(JSON)

    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
