from sqlalchemy import (
    JSON,
    Boolean,
    Column,
    DateTime,
    Time,
    Float,
    ForeignKey,
    Integer,
    String,
)
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func

from dfdb.session import Base


class ContractEvent(Base):
    __tablename__ = "contractevent"

    id = Column(Integer, primary_key=True, index=True)
    contract_id = Column(Integer, ForeignKey("contract.id"))
    action = Column(JSON)
    timestamp = Column(DateTime)
    penalty = Column(Float)
    supplied = Column(Float)
    actual = Column(Float)
    event_type = Column(String)
