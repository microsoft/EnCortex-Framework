from contextlib import contextmanager
from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

from dfdb.config import get_settings, get_azure_settings


settings = get_settings()
engine, SessionLocal, Base = None, None, declarative_base()
if settings.SQLALCHEMY_DATABASE_URI is not None:
    try:
        engine = create_engine(
            settings.SQLALCHEMY_DATABASE_URI
        )
        SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

        Base = declarative_base()
    except:
        engine, SessionLocal, Base = None, None, declarative_base()


# Dependency
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@contextmanager
def get_db_as_context():
    return get_db()